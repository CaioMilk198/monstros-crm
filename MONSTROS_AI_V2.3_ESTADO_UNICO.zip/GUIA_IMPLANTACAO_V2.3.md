# Implantação — MONSTROS AI Piloto 2.3

1. No GitHub, envie os arquivos `index.html`, `styles.css`, `app.js` e `monster-engine.js` desta pasta, substituindo os atuais.
2. Aguarde o deploy da Vercel ficar **Ready**.
3. Abra o sistema e pressione `Ctrl + F5` para ignorar o cache antigo.
4. Confira no menu lateral a indicação **PILOTO 2.3**.
5. Valide se Centro de Comando e Director mostram a mesma projeção e oportunidade.

Esta versão não exige nova migração SQL.
