# MONSTROS AI — Piloto 2.3

## Estado Único da Operação

- Dashboard, Director, reunião, Timeline e simulador passam a priorizar a mesma projeção por dias úteis.
- Oportunidade financeira deixa de alternar entre R$ 0,00 e o valor calculado.
- Briefing executivo agora mostra situação, oportunidade, causa, ação prioritária e ritmos diário atual/necessário.
- Radar do Director passa a exibir valores e nomes derivados dos dados atuais.
- Roteiro de reunião usa os mesmos números do Centro de Comando.
- Timeline utiliza receita e potencial do estado unificado.
- Fallbacks explicativos evitam cartões vazios ou excessivamente genéricos.
