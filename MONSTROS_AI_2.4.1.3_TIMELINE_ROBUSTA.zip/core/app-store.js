
(function(){
  const KEY='monstros_core_state_v241';
  const defaults={sellerId:'',missionId:'',view:'dashboard',period:'current',updatedAt:null};
  function read(){try{return {...defaults,...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch{return {...defaults}}}
  let state=read();
  const listeners=new Set();
  function persist(){state.updatedAt=new Date().toISOString();localStorage.setItem(KEY,JSON.stringify(state));}
  function emit(){listeners.forEach(fn=>{try{fn({...state})}catch(e){console.warn(e)}});}
  window.MonsterStore={
    get:()=>({...state}),
    set(patch={}){state={...state,...patch};persist();emit();return {...state};},
    selectSeller(id){return this.set({sellerId:id||''});},
    selectMission(id){return this.set({missionId:id||''});},
    navigate(view){return this.set({view:view||'dashboard'});},
    subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn);}
  };
})();
