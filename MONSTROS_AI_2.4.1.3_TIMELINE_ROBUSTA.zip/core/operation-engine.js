
(function(){
  const n=v=>Number(v||0);
  function build({dashboard={},engine={},director={},ranking=[]}={}){
    const s=dashboard.summary||{}, e=engine||dashboard.engine||director.engine||{};
    const p=e.projection||{}, h=e.health||{}, m=e.money||director.cost||{}, c=e.calendar||dashboard.calendar||{};
    const revenue=n(p.current_revenue ?? s.revenue), target=n(p.target ?? s.target), projection=n(p.projected_revenue ?? s.projection);
    const opportunity=n(m.total_opportunity ?? director?.radar?.opportunity);
    return {
      date:dashboard.date||director.date||null,revenue,target,projection,opportunity,
      attainment:target?revenue/target:0,projectedAttainment:target?projection/target:0,
      gap:Math.max(0,target-projection),orders:n(s.orders),ticket:n(s.average_ticket),
      cancellation:n(s.cancellation_rate),monsterIndex:n(h.monster_index),healthStatus:h.status||'—',
      elapsedDays:n(c.elapsed_business_days),remainingDays:n(c.remaining_business_days),totalDays:n(c.total_business_days),
      dailyRate:n(c.daily_rate||p.daily_rate),requiredDailyRate:n(p.required_daily_rate),
      money:{ticket:n(m.ticket_opportunity),cancellation:n(m.cancellation_loss||m.cancellation_opportunity),lowVolume:n(m.active_opportunity||m.low_volume_opportunity),total:opportunity},
      ranking:[...(ranking||[])]
    };
  }
  window.OperationEngine={build};
})();
