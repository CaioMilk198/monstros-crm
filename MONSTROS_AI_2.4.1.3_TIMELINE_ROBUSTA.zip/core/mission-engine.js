
(function(){
  async function list(client,limit=50){
    if(!client)return [];
    const {data,error}=await client.rpc('list_management_missions',{p_status:null,p_limit:limit});
    if(error) throw error; return data||[];
  }
  async function create(client,input){
    const args={
      p_title:input.title,p_seller_id:input.sellerId||null,p_reason:input.reason||null,
      p_action_text:input.action||null,p_priority:input.priority||'medium',
      p_estimated_impact:Number(input.impact||0),p_estimated_minutes:Number(input.minutes||20),
      p_due_date:input.dueDate||null
    };
    const {data,error}=await client.rpc('create_management_mission',args);
    if(error)throw error; return data;
  }
  async function status(client,id,status,note=null){
    const {data,error}=await client.rpc('update_management_mission_status',{p_mission_id:id,p_status:status,p_completion_note:note});
    if(error)throw error; return data;
  }
  window.MissionEngine={list,create,status};
})();
