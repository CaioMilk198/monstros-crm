
(function(){
  async function capture(client,date=null){
    if(!client)return null;
    const {data,error}=await client.rpc('capture_operation_snapshot',{p_date:date||new Date().toISOString().slice(0,10)});
    if(error){console.warn('Snapshot:',error.message);return null;} return data;
  }
  window.SnapshotEngine={capture};
})();
