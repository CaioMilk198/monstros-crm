
(function(){
  const LOCAL='monstros_operational_events';
  function local(){try{return JSON.parse(localStorage.getItem(LOCAL)||'[]')}catch{return[]}}
  async function log({client,profile,type,title,text,sellerId=null,missionId=null,impact=0,status=null}){
    const event={id:(crypto.randomUUID?.()||String(Date.now())),created_at:new Date().toISOString(),type,title,text,seller_id:sellerId,mission_id:missionId,impact:Number(impact||0),status};
    const rows=local(); rows.unshift(event); localStorage.setItem(LOCAL,JSON.stringify(rows.slice(0,500)));
    if(client&&profile?.company_id){
      const payload={company_id:profile.company_id,event_type:type,title,text,seller_id:sellerId,mission_id:missionId,impact:event.impact,status,created_by:profile.id};
      const {error}=await client.from('operational_events').insert(payload);
      if(error) console.warn('Operational event persistência:',error.message);
    }
    return event;
  }
  window.EventEngine={listLocal:local,log};
})();
