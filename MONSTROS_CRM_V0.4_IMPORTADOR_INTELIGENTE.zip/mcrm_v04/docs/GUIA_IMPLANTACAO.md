# GUIA DE IMPLANTAÇÃO — MONSTROS CRM SPRINT 2

## Parte A — Atualizar o Supabase

1. Abra o Supabase.
2. Entre em **SQL Editor**.
3. Clique em **New query**.
4. Abra o arquivo `SUPABASE_MIGRATION_V1_1.sql`.
5. Copie todo o conteúdo.
6. Cole na nova consulta.
7. Clique em **Run**.
8. O resultado esperado é `Success. No rows returned`.

## Parte B — Criar o primeiro usuário

1. Ainda no Supabase, abra **Authentication**.
2. Entre em **Users**.
3. A aplicação também permite criar a conta pela tela de cadastro.
4. Use seu e-mail e uma senha forte.
5. Caso a confirmação por e-mail esteja ligada, confirme o e-mail.

## Parte C — Testar a aplicação sem hospedagem

A forma mais confiável é usar um servidor local simples.

### Windows com Python instalado

1. Extraia esta pasta.
2. Clique na barra de endereço da pasta, digite `cmd` e pressione Enter.
3. Execute:

```bash
python -m http.server 8080
```

4. Abra no navegador:

```text
http://localhost:8080
```

### Sem Python

Publique pelo GitHub e Netlify conforme a Parte D.

## Parte D — Colocar no GitHub

1. Abra seu repositório `monstros-crm`.
2. Clique em **Add file → Upload files**.
3. Envie:
   - `index.html`
   - `styles.css`
   - `app.js`
   - `README.md`
4. Não envie nenhuma chave secreta.
5. Clique em **Commit changes**.

O GitHub permite enviar arquivos pelo navegador usando **Add file → Upload files**.

## Parte E — Hospedar gratuitamente no Netlify

1. Crie uma conta no Netlify usando seu GitHub.
2. Escolha **Add new project / Import an existing project**.
3. Escolha GitHub.
4. Autorize somente o repositório `monstros-crm`.
5. Como o projeto é estático:
   - Build command: deixe vazio.
   - Publish directory: `/` ou a raiz do projeto.
6. Publique.

O Netlify pode conectar um repositório GitHub e fazer uma nova publicação a cada atualização.

## Parte F — Configurar a aplicação pela primeira vez

1. Abra o endereço da aplicação.
2. Digite:
   - **Project URL** do Supabase.
   - **Publishable key** do Supabase.
3. Essas informações ficam apenas no armazenamento local do navegador.
4. Crie ou entre na sua conta.
5. Vá em **Configurações**.
6. Clique em **Ativar este usuário como primeiro administrador**.
7. Vá em **Importar planilha**.
8. Selecione a planilha da Equipe Monstros.
9. Confira a prévia.
10. Confirme a importação.
11. O sistema gerará Dashboard, Ranking e Missão do Dia.

## Importante

- A Publishable key é feita para uso no navegador com RLS configurado.
- A Secret key nunca deve ser compartilhada ou colocada no GitHub.
- Esta é uma versão piloto. Antes de cadastrar os 20 usuários, valide o fluxo com 1 administrador e 2 vendedores.
